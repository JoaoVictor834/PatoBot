module.exports = {
    chat: async function(message, value, x, vezes, dcids) {

    },

    death: async function(message, value, x, deaths, deathsids) {

    }
}