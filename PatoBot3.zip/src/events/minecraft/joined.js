const Event = require('../../structures/Event')
const { EmbedBuilder } = require('discord.js')

module.exports = class extends Event.mEvent {
    constructor(bot, client, ebot) {
        super(bot, client, ebot, {
            name: 'chat:joined'
        })
        
    } 
    
    run = (matches) => {
        
        const user = matches[0][0]

        const JoinEmbed = new EmbedBuilder()
          .setDescription(`O jogador *${user}* entrou no servidor.`)
          .setColor('FF000')

        this.client.chat.send({ embeds: [JoinEmbed] })

    }
}