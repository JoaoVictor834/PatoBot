### Oi Oi, souce do patobot se vira ai
